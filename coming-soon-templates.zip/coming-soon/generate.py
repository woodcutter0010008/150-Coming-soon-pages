#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import re
import random
from datetime import datetime, timedelta
from string import Template

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATES_DIR = os.path.join(BASE_DIR, "templates")
random.seed(1337)

FONT_PAIRS = [
    ("Poppins", "Inter"), ("Space Grotesk", "Inter"), ("Manrope", "Inter"),
    ("Sora", "Inter"), ("Plus Jakarta Sans", "Inter"), ("Outfit", "Inter"),
    ("Kanit", "Inter"), ("Montserrat", "Inter"), ("Rubik", "Inter"),
    ("Nunito", "Inter"), ("Urbanist", "Inter"), ("DM Sans", "Inter"),
    ("Quicksand", "Inter"), ("Comfortaa", "Inter")
]

COLOR_PALETTES = [
    ("#6C63FF", "#00D2FF", "#0b1020", "#E5E7EB"),
    ("#FF7A18", "#AF002D", "#0b1020", "#F9FAFB"),
    ("#FF3CAC", "#784BA0", "#0f172a", "#E2E8F0"),
    ("#00C6FB", "#005BEA", "#0b1020", "#E5E7EB"),
    ("#00F5A0", "#00D9F5", "#0b1020", "#F3F4F6"),
    ("#F9D423", "#FF4E50", "#0b1020", "#F9FAFB"),
    ("#A18CD1", "#FBC2EB", "#0b1020", "#F3F4F6"),
    ("#43E97B", "#38F9D7", "#0b1020", "#E5E7EB"),
    ("#FEE140", "#FA709A", "#0b1020", "#E5E7EB"),
    ("#8EC5FC", "#E0C3FC", "#0b1020", "#F9FAFB")
]

ICON_CDNS = [
    {
        "name": "fontawesome",
        "link": "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css",
        "feature_icons": [
            "fa-solid fa-bolt","fa-solid fa-shield","fa-solid fa-wand-magic-sparkles",
            "fa-solid fa-cloud","fa-solid fa-rocket","fa-solid fa-lock",
            "fa-solid fa-chart-line","fa-solid fa-brain","fa-solid fa-person-running"
        ],
        "social_icons": {
            "twitter": "fa-brands fa-x-twitter","github": "fa-brands fa-github",
            "dribbble": "fa-brands fa-dribbble","linkedin": "fa-brands fa-linkedin",
            "instagram": "fa-brands fa-instagram"
        }
    },
    {
        "name": "bootstrap-icons",
        "link": "https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css",
        "feature_icons": [
            "bi-lightning-charge-fill","bi-shield-lock-fill","bi-stars",
            "bi-cloud-arrow-down-fill","bi-rocket-takeoff-fill","bi-lock-fill",
            "bi-bar-chart-line-fill","bi-cpu-fill","bi-speedometer2"
        ],
        "social_icons": {
            "twitter": "bi-twitter-x","github": "bi-github",
            "dribbble": "bi-dribbble","linkedin": "bi-linkedin",
            "instagram": "bi-instagram"
        }
    },
    {
        "name": "unicons",
        "link": "https://unicons.iconscout.com/release/v4.0.8/css/line.css",
        "feature_icons": [
            "uil-bolt","uil-shield-check","uil-sparkles",
            "uil-cloud-download","uil-rocket","uil-lock",
            "uil-chart-line","uil-brain","uil-dashboard"
        ],
        "social_icons": {
            "twitter": "uil-twitter","github": "uil-github",
            "dribbble": "uil-dribbble","linkedin": "uil-linkedin",
            "instagram": "uil-instagram"
        }
    }
]

TIMER_STYLES = [
    "numeric","flip","circular","bars","dots","ring",
    "cards","neon","tiles","solar","liquid","typewriter"
]

NOUN_SETS = {
    "ai": [
        ("NovaAI","Weaving intelligent automation into everyday workflows."),
        ("EchoMind AI","Conversational intelligence that remembers, learns, and adapts."),
        ("Lumina Vision","Computer vision reimagined for creators and builders."),
        ("PromptForge","Turn rough ideas into polished results instantly."),
        ("Cortex Cloud","Deploy powerful models without the MLOps headache.")
    ],
    "fintech": [
        ("MintyPay","Payments so smooth, they feel invisible."),
        ("LedgerLoop","Realtime finance dashboards for growing teams."),
        ("YieldCraft","Automated treasury for modern startups."),
        ("TaxPilot","Smart tax prep that explains every number."),
        ("CoinHaven","Digital assets with bank-grade safety.")
    ],
    "health": [
        ("PulseWave","Health insights you can actually use."),
        ("FitOdyssey","Guided programs tailored by real coaches."),
        ("Nutrily","Personal nutrition, deliciously simple."),
        ("CalmNest","Micro-practices for modern minds."),
        ("Clinicly","Virtual care with a human touch.")
    ],
    "edtech": [
        ("StudyArc","Learning paths that feel like play."),
        ("Syllabi","Create, curate, and share lessons in minutes."),
        ("QuizBeam","Assessments with instant, actionable feedback."),
        ("LangFlow","Speak confidently with real-time coaching."),
        ("CodeSprout","From zero to shipped projects, fast.")
    ],
    "devtools": [
        ("ShipKit","From idea to deploy in one command."),
        ("LogHawk","Observability that reads like a story."),
        ("TestWeave","Effortless test nets, rock-solid releases."),
        ("BuildStream","Parallel build pipelines without the pain."),
        ("SpectraUI","A design system that designs itself.")
    ],
    "travel": [
        ("SkyTrail","Itineraries crafted by real explorers."),
        ("NomadNest","Long-stay travel without the guesswork."),
        ("GlobeMint","Your travel budget, beautifully planned."),
        ("VistaRail","Scenic routes for slow travel fans."),
        ("HarborHop","Coastal getaways, one ticket away.")
    ],
    "ecommerce": [
        ("CartMuse","Storefronts that sell themselves."),
        ("DropPilot","Inventory made effortless."),
        ("BrandBloom","From first click to loyal fan."),
        ("PricePulse","Smarter pricing, happier margins."),
        ("ShipSpark","Delightful delivery, every time.")
    ],
    "gaming": [
        ("PixelFable","Narratives that react to you."),
        ("ArenaRush","Competitive play without the toxicity."),
        ("NebulaRun","Arcade vibes, cosmic scale."),
        ("GuildForge","Communities that actually co-create."),
        ("LumenQuest","Mobile RPG that respects your time.")
    ],
    "marketing": [
        ("AdSymphony","Campaigns that compose themselves."),
        ("ViralCraft","Stories designed to spread."),
        ("AudienceOS","Own your audience, end to end."),
        ("BrandHarbor","Positioning that sticks."),
        ("FunnelFox","From awareness to action, beautifully mapped.")
    ],
    "events": [
        ("StageFlow","Run events like a Broadway pro."),
        ("MeetMint","Networking that actually works."),
        ("TicketNest","Ticketing without the fees."),
        ("ExpoPilot","Booth logistics on autopilot."),
        ("PulseFest","Festivals that feel personal.")
    ],
    "general": [
        ("Orbit","Something new is landing soon."),
        ("Mono","A minimal brand for maximal impact."),
        ("Prism","Colorful ideas, coming to life."),
        ("Silk","Elegance, refined for the web."),
        ("Flux","A fresh way to get things done.")
    ]
}

CATEGORIES_ORDER = [
    "ai","fintech","health","edtech","devtools","travel","ecommerce","gaming","marketing","events","general"
]


def slugify(text: str) -> str:
    text = re.sub(r"[^a-zA-Z0-9\-\s]", "", text)
    text = text.strip().lower().replace(" ", "-")
    text = re.sub(r"-+", "-", text)
    return text


def make_svg_logo(title: str, primary: str, secondary: str) -> str:
    initials = "".join([w[0] for w in title.split()][:2]).upper()
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 128 128" role="img" aria-label="{title} logo">
  <defs>
    <linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="{primary}"/>
      <stop offset="100%" stop-color="{secondary}"/>
    </linearGradient>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="6" stdDeviation="6" flood-color="rgba(0,0,0,0.25)"/>
    </filter>
  </defs>
  <g filter="url(#shadow)">
    <rect x="10" y="10" rx="28" ry="28" width="108" height="108" fill="url(#g)"/>
    <text x="50%" y="56%" dominant-baseline="middle" text-anchor="middle" font-family="Poppins, Inter, system-ui" font-weight="800" font-size="44" fill="#ffffff">{initials}</text>
  </g>
</svg>'''


def make_svg_favicon(primary: str, secondary: str) -> str:
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64">
  <defs>
    <linearGradient id="fg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="{primary}"/>
      <stop offset="100%" stop-color="{secondary}"/>
    </linearGradient>
  </defs>
  <circle cx="32" cy="32" r="26" fill="url(#fg)"/>
</svg>'''


def pick_font_pair(i: int):
    return FONT_PAIRS[i % len(FONT_PAIRS)]

def pick_palette(i: int):
    return COLOR_PALETTES[i % len(COLOR_PALETTES)]

def pick_icon_pack(i: int):
    return ICON_CDNS[i % len(ICON_CDNS)]

def pick_timer_style(i: int):
    return TIMER_STYLES[i % len(TIMER_STYLES)]


BACKGROUND_VARIANTS = [
    {"decor": "<div class=\"bg-ornaments\"></div>", "css": ".bg-ornaments::before,.bg-ornaments::after{content:'';position:fixed;width:60vmax;height:60vmax;filter:blur(80px);opacity:.35;z-index:-2}.bg-ornaments::before{top:-20vmax;left:-10vmax;background:radial-gradient(circle at 30% 30%, var(--color-primary), transparent 60%)}.bg-ornaments::after{bottom:-25vmax;right:-10vmax;background:radial-gradient(circle at 70% 70%, var(--color-secondary), transparent 60%)}"},
    {"decor": "<div class=\"bg-stripes\"></div>", "css": ".bg-stripes{position:fixed;inset:0;background:repeating-linear-gradient(45deg,rgba(255,255,255,.05) 0 12px,transparent 12px 24px);z-index:-2}"},
    {"decor": "<div class=\"bg-dots\"></div>", "css": ".bg-dots{position:fixed;inset:0;background-image:radial-gradient(rgba(255,255,255,.08) 1px,transparent 1px);background-size:22px 22px;z-index:-2}"},
    {"decor": "<div class=\"bg-grid\"></div>", "css": ".bg-grid{position:fixed;inset:0;background:linear-gradient(transparent 95%,rgba(255,255,255,.06) 95%),linear-gradient(90deg,transparent 95%,rgba(255,255,255,.06) 95%);background-size:32px 32px;z-index:-2}"},
    {"decor": "<div class=\"bg-noise\"></div>", "css": ".bg-noise{position:fixed;inset:0;background:linear-gradient(135deg,var(--color-dark),#0a0f1f)}.bg-noise::after{content:'';position:absolute;inset:0;background-image:url('data:image/svg+xml;utf8,<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"200\" height=\"200\"><filter id=\"n\"><feTurbulence baseFrequency=\"0.8\" numOctaves=\"2\" stitchTiles=\"stitch\"/></filter><rect width=\"100%\" height=\"100%\" filter=\"url(%23n)\" opacity=\"0.05\"/></svg>');mix-blend-mode:overlay}"},
    {"decor": "<svg class=\"bg-waves\" viewBox=\"0 0 1440 320\"><path fill=\"rgba(255,255,255,0.06)\" d=\"M0,64L60,53.3C120,43,240,21,360,32C480,43,600,85,720,101.3C840,117,960,107,1080,90.7C1200,75,1320,53,1380,42.7L1440,32L1440,0L0,0Z\"></path></svg>", "css": ".bg-waves{position:fixed;inset:auto 0 0 0;width:100%;z-index:-2}"}
]

NAV_VARIANTS = [
    {"html": "<header class=\"site-header glass\"><a class=\"brand\" href=\"#\"><img src=\"logo.svg\" width=\"36\" height=\"36\" alt=\"logo\"/><span>$title</span></a><button class=\"menu-toggle\" aria-expanded=\"false\" aria-controls=\"nav\"><span></span><span></span><span></span></button><nav id=\"nav\" class=\"nav\"><a href=\"#about\">About</a><a href=\"#notify\">Notify</a><a href=\"#features\">Features</a><a href=\"#contact\">Contact</a></nav></header>", "css": ".site-header.glass{backdrop-filter:blur(8px)}"},
    {"html": "<header class=\"site-header centered\"><a class=\"brand\" href=\"#\"><img src=\"logo.svg\" width=\"36\" height=\"36\" alt=\"logo\"/><span>$title</span></a><nav id=\"nav\" class=\"nav\"><a href=\"#about\">About</a><a href=\"#features\">Features</a><a href=\"#notify\">Notify</a></nav><button class=\"menu-toggle\" aria-expanded=\"false\" aria-controls=\"nav\"><span></span><span></span><span></span></button></header>", "css": ".site-header.centered .nav{justify-content:center}"},
    {"html": "<header class=\"site-header underline\"><a class=\"brand\" href=\"#\"><img src=\"logo.svg\" width=\"36\" height=\"36\" alt=\"logo\"/><span>$title</span></a><nav id=\"nav\" class=\"nav\"><a href=\"#about\">About</a><a href=\"#features\">Features</a><a href=\"#notify\">Notify</a><a href=\"#contact\">Contact</a></nav><button class=\"menu-toggle\" aria-expanded=\"false\" aria-controls=\"nav\"><span></span><span></span><span></span></button></header>", "css": ".site-header.underline{border-bottom:2px solid rgba(255,255,255,0.08)} .site-header.underline .nav a{background:transparent}"}
]

FOOTER_VARIANTS = [
    {"html": "<footer class=\"site-footer\"><div class=\"links\"><a href=\"#\">Privacy</a><a href=\"#\">Terms</a><a href=\"#\">Status</a></div><p>&copy; $year $title</p></footer>", "css": ""},
    {"html": "<footer class=\"site-footer center\"><p>&copy; $year $title — Thanks for visiting</p></footer>", "css": ".site-footer.center{justify-content:center}"}
]

EXTRA_SECTIONS = [
    {"html": "<section class=\"extra roadmap\"><h2>Roadmap</h2><ol><li>Alpha access</li><li>Public beta</li><li>General availability</li></ol></section>", "css": ".extra.roadmap ol{display:grid;gap:6px}"},
    {"html": "<section class=\"extra faq\"><h2>FAQ</h2><details><summary>When?</summary><p>Soon. Join the waitlist!</p></details><details><summary>Pricing?</summary><p>Fair and transparent.</p></details></section>", "css": ".extra.faq details{background:rgba(255,255,255,.05);padding:10px;border-radius:10px;margin:6px 0}"},
    {"html": "<section class=\"extra stats\"><h2>Stats</h2><div class=\"grid\"><div><strong>99.9%</strong><span>Uptime</span></div><div><strong>10k+</strong><span>Waitlist</span></div><div><strong>120+</strong><span>Countries</span></div></div></section>", "css": ".extra.stats .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px}.extra.stats strong{font-size:24px}"}
]

FORM_VARIANTS = [
    {"html": "<form id=\"notify\" class=\"notify pill\" action=\"#\" onsubmit=\"return false\" novalidate><input type=\"email\" placeholder=\"Your email\" aria-label=\"Email\" required /><button type=\"submit\"><i class=\"$notify_icon\"></i> Notify me</button></form>", "css": ".notify.pill input,.notify.pill button{border-radius:999px}"},
    {"html": "<form id=\"notify\" class=\"notify stacked\" action=\"#\" onsubmit=\"return false\" novalidate><input type=\"email\" placeholder=\"Email address\" required /><button type=\"submit\">Keep me posted</button></form>", "css": ".notify.stacked{flex-direction:column;align-items:stretch}"}
]

HTML_TPL = Template("""<!DOCTYPE html>
<html lang=\"en\"><head>
<meta charset=\"UTF-8\" /><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
<meta name=\"description\" content=\"$subtitle\" />
<title>$title — Coming Soon</title>
<link rel=\"icon\" type=\"image/svg+xml\" href=\"favicon.svg\" />
<link rel=\"preconnect\" href=\"https://fonts.googleapis.com\" />
<link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin />
<link href=\"$google_fonts\" rel=\"stylesheet\" />
<link rel=\"stylesheet\" href=\"$icon_cdn\" />
<link rel=\"stylesheet\" href=\"styles.css\" />
</head>
<body>
$decor
$nav
<main class=\"hero\">
  <section class=\"intro\">
    <h1>$title</h1>
    <p class=\"tagline\">$subtitle</p>
    <p class=\"desc\">$desc</p>
    $timer
    $form
    <div class=\"socials\">$social</div>
  </section>
  <section id=\"features\" class=\"features\">
    <h2>What we're building</h2>
    <ul>$features</ul>
  </section>
  $extra
</main>
$footer
<script>window.TARGET_DATE='$target';window.TIMER_STYLE='$timer_style';</script>
<script src=\"script.js\"></script>
</body></html>
""")

CSS_TPL = Template(""":root { --color-primary: $primary; --color-secondary: $secondary; --color-dark: $dark; --color-light: $light; --radius: 16px; }
* { box-sizing: border-box; }
html, body { height: 100%; }
body { margin: 0; font-family: '$font_body', Inter, system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif; color: var(--color-light); background: linear-gradient(135deg, var(--color-dark), #0a0f1f); overflow-x: hidden; }
.site-header { position: sticky; top: 0; z-index: 20; display: flex; align-items: center; justify-content: space-between; padding: 16px 20px; border-bottom: 1px solid rgba(255,255,255,0.06); }
.brand { display: flex; align-items: center; gap: 12px; color: #fff; text-decoration: none; font-weight: 800; font-family: '$font_head', $font_body, system-ui; }
.brand img { border-radius: 12px; box-shadow: 0 4px 14px rgba(0,0,0,0.25); }
.menu-toggle { display: inline-flex; flex-direction: column; gap: 5px; background: transparent; border: 0; cursor: pointer; }
.menu-toggle span { width: 26px; height: 2px; background: #fff; display: block; transition: transform .3s, opacity .3s; }
.menu-toggle.active span:nth-child(1) { transform: translateY(7px) rotate(45deg); }
.menu-toggle.active span:nth-child(2) { opacity: 0; }
.menu-toggle.active span:nth-child(3) { transform: translateY(-7px) rotate(-45deg); }
.nav { position: fixed; inset: 56px 16px auto 16px; display: grid; grid-auto-flow: column; gap: 14px; justify-content: end; }
.nav a { color: #cfd8ff; text-decoration: none; padding: 10px 12px; border-radius: 10px; background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.08); }
@media (max-width: 768px) { .nav { inset: 56px 16px auto 16px; background: rgba(10,15,31,0.85); padding: 12px; border-radius: 14px; border: 1px solid rgba(255,255,255,0.08); grid-auto-flow: row; justify-content: stretch; gap: 10px; transform-origin: top right; transform: scale(0.95); opacity: 0; pointer-events: none; transition: .2s ease; } .nav.show { transform: scale(1); opacity: 1; pointer-events: auto; } }
.hero { max-width: 1200px; margin: 0 auto; padding: 48px 20px 64px; display: grid; gap: 36px; }
.intro h1 { font-size: clamp(28px, 6vw, 64px); line-height: 1.05; margin: 0 0 10px; font-family: '$font_head', $font_body, system-ui; letter-spacing: -0.02em; }
.intro .tagline { font-size: clamp(16px, 2.2vw, 22px); opacity: 0.9; margin: 0 0 12px; }
.intro .desc { font-size: clamp(15px, 2vw, 18px); max-width: 70ch; opacity: 0.85; }
.notify { margin-top: 20px; display: flex; gap: 10px; flex-wrap: wrap; }
.notify input { flex: 1 1 240px; padding: 12px 14px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.15); background: rgba(255,255,255,0.05); color: #fff; }
.notify button { padding: 12px 16px; border-radius: 12px; border: 0; background: linear-gradient(90deg, var(--color-primary), var(--color-secondary)); color: #0a0f1f; font-weight: 800; cursor: pointer; }
.notify i { margin-right: 8px; }
.socials { display: flex; gap: 12px; margin-top: 16px; }
.socials a { color: #dde5ff; background: rgba(255,255,255,0.06); padding: 10px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.08); text-decoration: none; }
.features { background: rgba(255,255,255,0.04); padding: 20px; border-radius: 16px; border: 1px solid rgba(255,255,255,0.08); }
.features h2 { margin: 0 0 12px; font-family: '$font_head', $font_body, system-ui; }
.features ul { list-style: none; display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 12px; padding: 0; margin: 0; }
.features li { display: grid; grid-template-columns: 28px 1fr; align-items: center; gap: 10px; padding: 12px; background: rgba(255,255,255,0.04); border-radius: 12px; border: 1px solid rgba(255,255,255,0.08); }
.features i { color: var(--color-secondary); font-size: 18px; }
.site-footer { margin: 30px auto 0; padding: 20px; display: flex; gap: 14px; flex-wrap: wrap; align-items: center; justify-content: space-between; max-width: 1200px; border-top: 1px dashed rgba(255,255,255,0.12); }
.site-footer .links { display: flex; gap: 14px; flex-wrap: wrap; }
.site-footer a { color: #cfd8ff; text-decoration: none; opacity: 0.9; }
/* Timers */
.timer { margin-top: 22px; display: grid; gap: 12px; }
.timer .t-unit, .timer .glow, .timer .tile, .timer .card { display: grid; gap: 6px; place-items: center; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.08); border-radius: 14px; padding: 14px; min-width: 120px; }
.timer label { opacity: 0.8; font-size: 12px; }
.timer span { font-family: '$font_head', $font_body, system-ui; font-size: clamp(26px, 6vw, 44px); font-weight: 800; letter-spacing: 0.04em; }
.timer.numeric { grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); }
.timer.flip { grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); }
.flip-unit span { display: block; background: linear-gradient(180deg, rgba(255,255,255,0.12), rgba(255,255,255,0.02)); padding: 16px; border-radius: 10px; box-shadow: inset 0 -2px 0 rgba(0,0,0,0.2); }
.timer.circular { grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); align-items: stretch; }
.timer.circular .circle { position: relative; text-align: center; }
.timer.circular svg { width: 120px; height: 120px; }
.timer.circular .bg { fill: none; stroke: rgba(255,255,255,0.15); stroke-width: 12; }
.timer.circular .prog { fill: none; stroke-linecap: round; stroke-width: 12; stroke-dasharray: 339; stroke-dashoffset: 339; transform: rotate(-90deg); transform-origin: 50% 50%; }
.timer.bars { grid-template-columns: 1fr; }
.timer.bars .bar { position: relative; background: rgba(255,255,255,0.06); border-radius: 12px; overflow: hidden; padding: 10px 14px; margin-bottom: 6px; }
.timer.bars .bar .fill { position: absolute; left: 0; top: 0; bottom: 0; width: 0%; background: linear-gradient(90deg, var(--color-primary), var(--color-secondary)); opacity: 0.7; }
.timer.dots .dot-row { display: grid; grid-template-columns: 1fr auto auto; align-items: center; gap: 10px; padding: 10px; border-radius: 12px; background: rgba(255,255,255,0.06); }
.timer.dots .dots-wrap { display: grid; grid-auto-flow: column; gap: 6px; align-items: center; }
.timer.dots .dots-wrap .dot { width: 10px; height: 10px; background: var(--color-secondary); border-radius: 50%; opacity: 0.9; }
.timer.ring .ring-wrap { background: rgba(255,255,255,0.06); border-radius: 20px; padding: 12px; border: 1px solid rgba(255,255,255,0.08); }
.timer.ring svg { width: 100%; height: 40px; }
.timer.ring .ring-bg { x: 0; y: 14; width: 100%; height: 12px; rx: 6px; fill: rgba(255,255,255,0.12); }
.timer.ring .ring-fg { x: 0; y: 14; width: 0%; height: 12px; rx: 6px; }
.timer.cards { grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); }
.timer.cards .card .num { font-size: clamp(28px, 6vw, 48px); }
.timer.neon { grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); }
.timer.neon .glow { background: rgba(10,15,31,0.4); box-shadow: 0 0 20px var(--color-primary), inset 0 0 20px rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.2); }
.timer.tiles { grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); }
.timer.tiles .tile { border: 1px dashed rgba(255,255,255,0.2); }
.timer.solar { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
.orb { aspect-ratio: 1; border-radius: 50%; display: grid; place-items: center; background: radial-gradient(circle at 30% 30%, var(--color-secondary), rgba(255,255,255,0.06)); border: 1px solid rgba(255,255,255,0.08); }
.timer.liquid { grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); }
.liquid-meter { position: relative; height: 120px; overflow: hidden; }
.liquid-fill { position: absolute; left: 0; bottom: -20%; width: 100%; height: 0%; background: linear-gradient(180deg, var(--color-primary), var(--color-secondary)); }
.timer.typewriter #typewriter-output { font-family: '$font_head', $font_body, system-ui; font-size: clamp(20px, 4vw, 28px); min-height: 40px; border-right: 2px solid var(--color-secondary); white-space: nowrap; overflow: hidden; animation: caret 1s steps(1) infinite; }
@keyframes caret { 50% { border-color: transparent; } }
.floaty { position: fixed; pointer-events: none; z-index: -1; opacity: 0.25; filter: blur(0.2px); }
""")

JS_CONTENT = """(function(){
  const nav = document.getElementById('nav');
  const toggle = document.querySelector('.menu-toggle');
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const open = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', String(!open));
      toggle.classList.toggle('active');
      nav.classList.toggle('show');
    });
  }
  function spawnFloaties(){
    const colors = ['var(--color-primary)','var(--color-secondary)','rgba(255,255,255,0.5)'];
    for (let i = 0; i < 16; i++) {
      const el = document.createElement('div');
      el.className = 'floaty';
      const size = Math.random()*24+10;
      el.style.width = size+'px';
      el.style.height = size+'px';
      el.style.left = Math.random()*100+'vw';
      el.style.top = Math.random()*100+'vh';
      el.style.borderRadius = Math.random()>0.5? '50%':'12px';
      el.style.background = `radial-gradient(circle at 30% 30%, ${colors[i%colors.length]}, transparent 70%)`;
      el.style.animation = `float ${8 + Math.random()*12}s ease-in-out ${Math.random()*-10}s infinite`;
      document.body.appendChild(el);
    }
  }
  const style = document.createElement('style');
  style.textContent = `@keyframes float { 0%, 100% { transform: translateY(0) } 50% { transform: translateY(-20px) } }`;
  document.head.appendChild(style);
  spawnFloaties();
  const target = new Date(window.TARGET_DATE);
  function pad(n){ return String(n).padStart(2,'0'); }
  function update(){
    const now = new Date();
    let diff = Math.max(0, target - now);
    const totalSeconds = Math.floor(diff/1000);
    const days = Math.floor(totalSeconds/86400);
    const hours = Math.floor((totalSeconds%86400)/3600);
    const minutes = Math.floor((totalSeconds%3600)/60);
    const seconds = totalSeconds%60;
    const id = (x)=>document.getElementById(x);
    if (id('days')) id('days').textContent = pad(days);
    if (id('hours')) id('hours').textContent = pad(hours);
    if (id('minutes')) id('minutes').textContent = pad(minutes);
    if (id('seconds')) id('seconds').textContent = pad(seconds);
  }
  update();
  setInterval(update, 1000);
  const form = document.getElementById('notify');
  if (form){
    form.addEventListener('submit', (e)=>{
      const input = form.querySelector('input[type=email]');
      if (!input) return;
      input.disabled = true; setTimeout(()=>{ input.value=''; input.disabled=false; alert('Thanks! We\\'ll be in touch.'); }, 600);
    });
  }
})();
"""


def build_timer_markup(style: str) -> str:
    timers = {
        "numeric": """
        <div class=\"timer numeric\">
            <div class=\"t-unit\"><span id=\"days\">00</span><label>Days</label></div>
            <div class=\"t-unit\"><span id=\"hours\">00</span><label>Hours</label></div>
            <div class=\"t-unit\"><span id=\"minutes\">00</span><label>Minutes</label></div>
            <div class=\"t-unit\"><span id=\"seconds\">00</span><label>Seconds</label></div>
        </div>
        """,
        "flip": """
        <div class=\"timer flip\">
            <div class=\"flip-unit\" data-unit=\"days\"><span id=\"days\">00</span><label>Days</label></div>
            <div class=\"flip-unit\" data-unit=\"hours\"><span id=\"hours\">00</span><label>Hours</label></div>
            <div class=\"flip-unit\" data-unit=\"minutes\"><span id=\"minutes\">00</span><label>Minutes</label></div>
            <div class=\"flip-unit\" data-unit=\"seconds\"><span id=\"seconds\">00</span><label>Seconds</label></div>
        </div>
        """,
        "circular": """
        <div class=\"timer circular\">
            <div class=\"circle\" data-unit=\"days\"><svg viewBox=\"0 0 120 120\"><circle class=\"bg\" cx=\"60\" cy=\"60\" r=\"54\"/><circle class=\"prog\" cx=\"60\" cy=\"60\" r=\"54\"/></svg><span id=\"days\">00</span><label>Days</label></div>
            <div class=\"circle\" data-unit=\"hours\"><svg viewBox=\"0 0 120 120\"><circle class=\"bg\" cx=\"60\" cy=\"60\" r=\"54\"/><circle class=\"prog\" cx=\"60\" cy=\"60\" r=\"54\"/></svg><span id=\"hours\">00</span><label>Hours</label></div>
            <div class=\"circle\" data-unit=\"minutes\"><svg viewBox=\"0 0 120 120\"><circle class=\"bg\" cx=\"60\" cy=\"60\" r=\"54\"/><circle class=\"prog\" cx=\"60\" cy=\"60\" r=\"54\"/></svg><span id=\"minutes\">00</span><label>Minutes</label></div>
            <div class=\"circle\" data-unit=\"seconds\"><svg viewBox=\"0 0 120 120\"><circle class=\"bg\" cx=\"60\" cy=\"60\" r=\"54\"/><circle class=\"prog\" cx=\"60\" cy=\"60\" r=\"54\"/></svg><span id=\"seconds\">00</span><label>Seconds</label></div>
        </div>
        """,
        "bars": """
        <div class=\"timer bars\">
            <div class=\"bar\" data-unit=\"days\"><div class=\"fill\"></div><span id=\"days\">00</span><label>Days</label></div>
            <div class=\"bar\" data-unit=\"hours\"><div class=\"fill\"></div><span id=\"hours\">00</span><label>Hours</label></div>
            <div class=\"bar\" data-unit=\"minutes\"><div class=\"fill\"></div><span id=\"minutes\">00</span><label>Minutes</label></div>
            <div class=\"bar\" data-unit=\"seconds\"><div class=\"fill\"></div><span id=\"seconds\">00</span><label>Seconds</label></div>
        </div>
        """,
        "dots": """
        <div class=\"timer dots\">
            <div class=\"dot-row\" data-unit=\"days\"><div class=\"dots-wrap\"></div><span id=\"days\">00</span><label>Days</label></div>
            <div class=\"dot-row\" data-unit=\"hours\"><div class=\"dots-wrap\"></div><span id=\"hours\">00</span><label>Hours</label></div>
            <div class=\"dot-row\" data-unit=\"minutes\"><div class=\"dots-wrap\"></div><span id=\"minutes\">00</span><label>Minutes</label></div>
            <div class=\"dot-row\" data-unit=\"seconds\"><div class=\"dots-wrap\"></div><span id=\"seconds\">00</span><label>Seconds</label></div>
        </div>
        """,
        "cards": """
        <div class=\"timer cards\">
            <div class=\"card\"><div class=\"num\" id=\"days\">00</div><div class=\"label\">Days</div></div>
            <div class=\"card\"><div class=\"num\" id=\"hours\">00</div><div class=\"label\">Hours</div></div>
            <div class=\"card\"><div class=\"num\" id=\"minutes\">00</div><div class=\"label\">Minutes</div></div>
            <div class=\"card\"><div class=\"num\" id=\"seconds\">00</div><div class=\"label\">Seconds</div></div>
        </div>
        """,
        "neon": """
        <div class=\"timer neon\"><div class=\"glow\"><span id=\"days\">00</span><label>Days</label></div><div class=\"glow\"><span id=\"hours\">00</span><label>Hours</label></div><div class=\"glow\"><span id=\"minutes\">00</span><label>Minutes</label></div><div class=\"glow\"><span id=\"seconds\">00</span><label>Seconds</label></div></div>
        """,
        "tiles": """
        <div class=\"timer tiles\"><div class=\"tile\" data-unit=\"days\"><span id=\"days\">00</span><label>Days</label></div><div class=\"tile\" data-unit=\"hours\"><span id=\"hours\">00</span><label>Hours</label></div><div class=\"tile\" data-unit=\"minutes\"><span id=\"minutes\">00</span><label>Minutes</label></div><div class=\"tile\" data-unit=\"seconds\"><span id=\"seconds\">00</span><label>Seconds</label></div></div>
        """,
        "solar": """
        <div class=\"timer solar\"><div class=\"orb orbit-days\"><span id=\"days\">00</span></div><div class=\"orb orbit-hours\"><span id=\"hours\">00</span></div><div class=\"orb orbit-minutes\"><span id=\"minutes\">00</span></div><div class=\"orb orbit-seconds\"><span id=\"seconds\">00</span></div></div>
        """,
        "liquid": """
        <div class=\"timer liquid\"><div class=\"liquid-meter\" data-unit=\"days\"><div class=\"liquid-fill\"></div><span id=\"days\">00</span><label>Days</label></div><div class=\"liquid-meter\" data-unit=\"hours\"><div class=\"liquid-fill\"></div><span id=\"hours\">00</span><label>Hours</label></div><div class=\"liquid-meter\" data-unit=\"minutes\"><div class=\"liquid-fill\"></div><span id=\"minutes\">00</span><label>Minutes</label></div><div class=\"liquid-meter\" data-unit=\"seconds\"><div class=\"liquid-fill\"></div><span id=\"seconds\">00</span><label>Seconds</label></div></div>
        """,
        "typewriter": """
        <div class=\"timer typewriter\"><div id=\"typewriter-output\" aria-live=\"polite\"></div></div>
        """,
    }
    return timers.get(style, timers["numeric"])


def generate_projects(total: int) -> list:
    projects = []
    pool = []
    for c in CATEGORIES_ORDER:
        for name, tag in NOUN_SETS[c]:
            pool.append((c, name, tag))
    descriptors = ["Pro","Studio","OS","Cloud","One","Flow","X","Prime","Edge","HQ","Lab","Works","Kit","Desk","Hub","Nest","Wave","Forge","Pulse","Spark"]
    idx = 0
    while len(projects) < total:
        cat, base, tag = pool[idx % len(pool)]
        title = f"{base} {random.choice(descriptors)}{idx}" if idx >= len(pool) else base
        projects.append({"category": cat, "title": title, "tagline": tag})
        idx += 1
    return projects[:total]


def template_paths(slug: str) -> dict:
    folder = os.path.join(TEMPLATES_DIR, slug)
    return {
        "folder": folder,
        "html": os.path.join(folder, "index.html"),
        "css": os.path.join(folder, "styles.css"),
        "js": os.path.join(folder, "script.js"),
        "logo": os.path.join(folder, "logo.svg"),
        "favicon": os.path.join(folder, "favicon.svg"),
    }


def write_file(path: str, content: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)


def make_svg_logo_simple(title: str, primary: str, secondary: str) -> str:
    initials = "".join([w[0] for w in title.split()][:2]).upper()
    return f"<svg xmlns='http://www.w3.org/2000/svg' width='96' height='96' viewBox='0 0 96 96'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='{primary}'/><stop offset='1' stop-color='{secondary}'/></linearGradient></defs><rect x='8' y='8' width='80' height='80' rx='20' fill='url(#g)'/><text x='50%' y='54%' text-anchor='middle' dominant-baseline='middle' font-family='Poppins, Inter, system-ui' font-size='34' font-weight='800' fill='#fff'>{initials}</text></svg>"


def generate_templates(total: int = 155):
    projects = generate_projects(total)
    pages = []
    for i, proj in enumerate(projects):
        title = proj["title"]
        slug = f"t{str(i+1).zfill(3)}-{slugify(title)}"
        category = proj["category"]
        tagline = proj["tagline"]
        fonts = pick_font_pair(i)
        palette = pick_palette(i)
        icons = pick_icon_pack(i)
        timer_style = pick_timer_style(i)
        features = {
            "ai": ["On-device inference","Private by default","Realtime adaptation","One-click export"],
            "fintech": ["Bank-grade security","Instant payouts","Smart reconciliation","Multi-currency"],
            "health": ["Personal plans","Clinician-backed","Daily check-ins","Insights that guide"],
            "edtech": ["Adaptive lessons","Peer challenges","AI tutoring","Project-based"],
            "devtools": ["CLI & UI","Observable pipelines","Type-safe SDK","Plugin ecosystem"],
            "travel": ["Smart itineraries","Visa guidance","Budget tracker","Offline maps"],
            "ecommerce": ["Headless ready","Checkout boosts","Zero-config SEO","1-click returns"],
            "gaming": ["Fair matchmaking","Co-op first","Seasonal drops","Cloud saves"],
            "marketing": ["Audience graph","Creative studio","A/B done right","Attribution clarity"],
            "events": ["Lightning ticketing","Sponsor CRM","Stage cues","Live analytics"],
            "general": ["Beautiful defaults","Seamless sync","Fast by design","Built-in privacy"],
        }.get(category, ["Beautiful defaults","Seamless sync","Fast by design","Built-in privacy"])

        # Uniqueness selection
        b_idx = (i * 11 + 1) % len(BACKGROUND_VARIANTS)
        n_idx = (i * 13 + 4) % len(NAV_VARIANTS)
        f_idx = (i * 17 + 5) % len(FOOTER_VARIANTS)
        fm_idx = (i * 19 + 2) % len(FORM_VARIANTS)
        x_idx = (i * 23 + 6) % len(EXTRA_SECTIONS)

        # target date
        days_ahead = random.randint(45, 160)
        target_date = datetime.utcnow() + timedelta(days=days_ahead, hours=random.randint(0,23), minutes=random.randint(0,59))

        features_list = ''.join(
            [f'<li><i class="{icons["feature_icons"][k % len(icons["feature_icons"]) ]}"></i><span>{feat}</span></li>' for k, feat in enumerate(features)]
        )
        social = icons["social_icons"]
        social_html = (
            f'<a href="#" aria-label="Twitter"><i class="{social["twitter"]}"></i></a>'
            f'<a href="#" aria-label="GitHub"><i class="{social["github"]}"></i></a>'
            f'<a href="#" aria-label="Dribbble"><i class="{social["dribbble"]}"></i></a>'
            f'<a href="#" aria-label="LinkedIn"><i class="{social["linkedin"]}"></i></a>'
            f'<a href="#" aria-label="Instagram"><i class="{social["instagram"]}"></i></a>'
        )

        html = HTML_TPL.substitute(
            title=title,
            subtitle=tagline,
            desc=f"{title} is crafting a new kind of {category}. {tagline}",
            google_fonts=f"https://fonts.googleapis.com/css2?family={fonts[0].replace(' ', '+')}:wght@400;600;800&family={fonts[1].replace(' ', '+')}:wght@400;600&display=swap",
            icon_cdn=icons["link"],
            timer=build_timer_markup(timer_style),
            form=Template(FORM_VARIANTS[fm_idx]["html"]).substitute(notify_icon=icons["feature_icons"][0]),
            social=social_html,
            features=features_list,
            extra=EXTRA_SECTIONS[x_idx]["html"],
            footer=Template(FOOTER_VARIANTS[f_idx]["html"]).substitute(year=datetime.utcnow().year, title=title),
            decor=BACKGROUND_VARIANTS[b_idx]["decor"],
            target=target_date.strftime("%Y-%m-%dT%H:%M:%SZ"),
            timer_style=timer_style,
            nav=Template(NAV_VARIANTS[n_idx]["html"]).substitute(title=title),
        )

        css = CSS_TPL.substitute(
            primary=palette[0], secondary=palette[1], dark=palette[2], light=palette[3],
            font_head=fonts[0], font_body=fonts[1]
        )
        css += "\n" + BACKGROUND_VARIANTS[b_idx]["css"] + "\n" + NAV_VARIANTS[n_idx]["css"] + "\n" + FOOTER_VARIANTS[f_idx]["css"] + "\n" + EXTRA_SECTIONS[x_idx]["css"] + "\n" + FORM_VARIANTS[fm_idx]["css"]

        js = JS_CONTENT

        paths = template_paths(slug)
        write_file(paths["logo"], make_svg_logo_simple(title, palette[0], palette[1]))
        write_file(paths["favicon"], make_svg_favicon(palette[0], palette[1]))
        write_file(paths["html"], html)
        write_file(paths["css"], css)
        write_file(paths["js"], js)
        pages.append({"slug": slug, "title": title})
    return pages


def generate_connector(pages: list):
    items = ''.join([
        f"<a class=\"card\" href=\"templates/{p['slug']}/index.html\"><span class=\"tag\">{p['slug']}</span><h3>{p['title']}</h3></a>" for p in pages
    ])
    content = f"""<!DOCTYPE html>
<html lang=\"en\"><head>
<meta charset=\"UTF-8\" /><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
<title>Coming Soon Gallery (155)</title>
<link rel=\"preconnect\" href=\"https://fonts.googleapis.com\" />
<link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin />
<link href=\"https://fonts.googleapis.com/css2?family=Manrope:wght@400;600;800&display=swap\" rel=\"stylesheet\" />
<style>
:root {{ --bg:#0b1020; --fg:#e5e7eb; --card:#121a30; --ring:#3b82f6; }}
* {{ box-sizing:border-box; }}
body {{ margin:0; font-family:Manrope, system-ui, -apple-system, Segoe UI, Roboto, Arial; background: radial-gradient(1200px 800px at 10% -10%, rgba(255,255,255,0.06), transparent), linear-gradient(135deg,#0b1020,#0a0f1f); color:var(--fg); }}
header {{ max-width:1200px; margin:0 auto; padding:24px 20px; display:flex; align-items:baseline; justify-content:space-between; }}
h1 {{ margin:0; font-size:clamp(22px,4vw,36px); }}
.actions a {{ color:var(--fg); text-decoration:none; background:#1a2440; padding:10px 12px; border-radius:12px; border:1px solid rgba(255,255,255,0.08); }}
main {{ max-width:1200px; margin:0 auto; padding:8px 20px 40px; }}
.grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(240px,1fr)); gap:12px; }}
.card {{ display:block; padding:18px; border-radius:14px; background:var(--card); color:var(--fg); text-decoration:none; border:1px solid rgba(255,255,255,0.08); position:relative; }}
.card:hover {{ outline:2px solid var(--ring); }}
.card .tag {{ position:absolute; top:12px; right:12px; background:rgba(59,130,246,0.12); border:1px solid rgba(59,130,246,0.35); color:#93c5fd; font-size:12px; padding:4px 8px; border-radius:999px; }}
footer {{ max-width:1200px; margin:0 auto; padding:24px 20px; opacity:.8; }}
</style></head>
<body>
<header><h1>Coming Soon Templates Gallery</h1><div class=\"actions\"><a href=\"tutorial.html\">Customization Tutorial</a></div></header>
<main><div class=\"grid\">{items}</div></main>
<footer><p>155 unique, responsive, HTML/CSS/JS coming soon pages — generated for you.</p></footer>
</body></html>
"""
    write_file(os.path.join(BASE_DIR, "index.html"), content)


def generate_tutorial():
    content = """<!DOCTYPE html>
<html lang=\"en\"><head>
<meta charset=\"UTF-8\" /><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
<title>Customization Tutorial</title>
<link rel=\"preconnect\" href=\"https://fonts.googleapis.com\" />
<link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin />
<link href=\"https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap\" rel=\"stylesheet\" />
<style>
:root { --bg:#0b1020; --fg:#e5e7eb; --muted:#9aa3b2; --card:#121a30; }
* { box-sizing:border-box; }
body { margin:0; font-family:Inter, system-ui, -apple-system, Segoe UI, Roboto, Arial; background: linear-gradient(135deg, #0b1020, #0a0f1f); color:var(--fg); }
main { max-width:900px; margin:0 auto; padding:28px 20px 48px; }
h1,h2 { margin:0 0 12px; }
section { background:var(--card); border:1px solid rgba(255,255,255,0.1); padding:16px; border-radius:14px; margin-bottom:14px; }
code,pre { background:#0f162c; color:#cbd5e1; padding:2px 6px; border-radius:6px; }
a { color:#93c5fd; }
ul { margin:8px 0 0 22px; }
</style></head>
<body>
<main>
<h1>Customize your Coming Soon templates</h1>
<p>This guide explains how to change logos, favicons, counters, backgrounds, titles, paragraphs, icons, and floating elements.</p>
<section><h2>Change the logo</h2><p>Replace <code>logo.svg</code> inside any template folder. Keep the filename the same. You can edit colors inside the SVG (look for <code>stop-color</code> or <code>fill</code> attributes).</p></section>
<section><h2>Edit the favicon</h2><p>Swap <code>favicon.svg</code> with your own or edit its gradient colors for a quick brand match.</p></section>
<section><h2>Change the counter target</h2><p>Open <code>index.html</code> and update <code>window.TARGET_DATE</code> to a new ISO date like <code>2025-12-31T17:00:00Z</code>. The timer updates automatically every second.</p><p><strong>Reset the counter:</strong> set a new future date. If the target is past, the counter stops at zero.</p></section>
<section><h2>Switch timer style</h2><p>Update <code>window.TIMER_STYLE</code> in <code>index.html</code> to one of: <code>numeric</code>, <code>flip</code>, <code>circular</code>, <code>bars</code>, <code>dots</code>, <code>ring</code>, <code>cards</code>, <code>neon</code>, <code>tiles</code>, <code>solar</code>, <code>liquid</code>, <code>typewriter</code>.</p></section>
<section><h2>Change colors & fonts</h2><p>Open <code>styles.css</code> and edit CSS variables under <code>:root</code> for primary/secondary colors. Update the Google Fonts link in <code>index.html</code> to try different typefaces.</p></section>
<section><h2>Background & animations</h2><p>Backgrounds are controlled by variant CSS at the end of <code>styles.css</code>. Floating shapes are added in <code>script.js</code> (function <code>spawnFloaties</code>).</p></section>
<section><h2>Titles, paragraphs, and icons</h2><p>Edit the text in <code>index.html</code>. Feature icons come from the included icon CDN. Replace icon classes with any from the same library.</p></section>
<section><h2>Responsive menu & footer</h2><p>Navigation and footer vary per template. Tweak their HTML blocks in <code>index.html</code> and adjust CSS at the bottom of <code>styles.css</code>.</p></section>
<section><h2>Newsletter form</h2><p>The form is front-end only. Connect it to your provider by changing the handler in <code>script.js</code> to call your API.</p></section>
<p>Start from the gallery <a href=\"index.html\">index</a> and open any template.</p>
</main>
</body></html>
"""
    write_file(os.path.join(BASE_DIR, "tutorial.html"), content)


def main():
    os.makedirs(TEMPLATES_DIR, exist_ok=True)
    pages = generate_templates(155)
    generate_connector(pages)
    generate_tutorial()
    print(f"Generated {len(pages)} templates at {TEMPLATES_DIR}")


if __name__ == "__main__":
    main()