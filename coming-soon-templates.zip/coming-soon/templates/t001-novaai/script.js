(function(){
  const nav = document.getElementById('nav');
  const toggle = document.querySelector('.menu-toggle');
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const open = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', String(!open));
      toggle.classList.toggle('active');
      nav.classList.toggle('show');
    });
  }
  function spawnFloaties(){
    const colors = ['var(--color-primary)','var(--color-secondary)','rgba(255,255,255,0.5)'];
    for (let i = 0; i < 16; i++) {
      const el = document.createElement('div');
      el.className = 'floaty';
      const size = Math.random()*24+10;
      el.style.width = size+'px';
      el.style.height = size+'px';
      el.style.left = Math.random()*100+'vw';
      el.style.top = Math.random()*100+'vh';
      el.style.borderRadius = Math.random()>0.5? '50%':'12px';
      el.style.background = `radial-gradient(circle at 30% 30%, ${colors[i%colors.length]}, transparent 70%)`;
      el.style.animation = `float ${8 + Math.random()*12}s ease-in-out ${Math.random()*-10}s infinite`;
      document.body.appendChild(el);
    }
  }
  const style = document.createElement('style');
  style.textContent = `@keyframes float { 0%, 100% { transform: translateY(0) } 50% { transform: translateY(-20px) } }`;
  document.head.appendChild(style);
  spawnFloaties();
  const target = new Date(window.TARGET_DATE);
  function pad(n){ return String(n).padStart(2,'0'); }
  function update(){
    const now = new Date();
    let diff = Math.max(0, target - now);
    const totalSeconds = Math.floor(diff/1000);
    const days = Math.floor(totalSeconds/86400);
    const hours = Math.floor((totalSeconds%86400)/3600);
    const minutes = Math.floor((totalSeconds%3600)/60);
    const seconds = totalSeconds%60;
    const id = (x)=>document.getElementById(x);
    if (id('days')) id('days').textContent = pad(days);
    if (id('hours')) id('hours').textContent = pad(hours);
    if (id('minutes')) id('minutes').textContent = pad(minutes);
    if (id('seconds')) id('seconds').textContent = pad(seconds);
  }
  update();
  setInterval(update, 1000);
  const form = document.getElementById('notify');
  if (form){
    form.addEventListener('submit', (e)=>{
      const input = form.querySelector('input[type=email]');
      if (!input) return;
      input.disabled = true; setTimeout(()=>{ input.value=''; input.disabled=false; alert('Thanks! We\'ll be in touch.'); }, 600);
    });
  }
})();
