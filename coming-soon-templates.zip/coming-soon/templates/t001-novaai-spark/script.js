(function(){
  const nav = document.getElementById('nav');
  const toggle = document.querySelector('.menu-toggle');
  toggle.addEventListener('click', () => {
    const open = toggle.getAttribute('aria-expanded') === 'true';
    toggle.setAttribute('aria-expanded', String(!open));
    toggle.classList.toggle('active');
    nav.classList.toggle('show');
  });
  function spawnFloaties(){
    const colors = ['var(--color-primary)','var(--color-secondary)','rgba(255,255,255,0.5)'];
    for (let i = 0; i < 16; i++) {
      const el = document.createElement('div');
      el.className = 'floaty';
      const size = Math.random()*24+10;
      el.style.width = size+'px';
      el.style.height = size+'px';
      el.style.left = Math.random()*100+'vw';
      el.style.top = Math.random()*100+'vh';
      el.style.borderRadius = Math.random()>0.5? '50%':'12px';
      el.style.background = `radial-gradient(circle at 30% 30%, ${colors[i%colors.length]}, transparent 70%)`;
      el.style.animation = `float ${8 + Math.random()*12}s ease-in-out ${Math.random()*-10}s infinite`;
      document.body.appendChild(el);
    }
  }
  const style = document.createElement('style');
  style.textContent = `@keyframes float { 0%, 100% { transform: translateY(0) } 50% { transform: translateY(-20px) } }`;
  document.head.appendChild(style);
  spawnFloaties();
  const target = new Date(window.TARGET_DATE);
  function pad(n){ return String(n).padStart(2,'0'); }
  function update(){
    const now = new Date();
    let diff = Math.max(0, target - now);
    const totalSeconds = Math.floor(diff/1000);
    const days = Math.floor(totalSeconds/86400);
    const hours = Math.floor((totalSeconds%86400)/3600);
    const minutes = Math.floor((totalSeconds%3600)/60);
    const seconds = totalSeconds%60;
    const id = (x)=>document.getElementById(x);
    if (id('days')) id('days').textContent = pad(days);
    if (id('hours')) id('hours').textContent = pad(hours);
    if (id('minutes')) id('minutes').textContent = pad(minutes);
    if (id('seconds')) id('seconds').textContent = pad(seconds);
    const style = window.TIMER_STYLE;
    if (style === 'circular'){
      document.querySelectorAll('.timer.circular .circle').forEach((el)=>{
        const unit = el.getAttribute('data-unit');
        const r = 54; const circ = 2*Math.PI*r; let ratio = 0;
        if (unit==='days') ratio = Math.min(1, days/30);
        if (unit==='hours') ratio = hours/24;
        if (unit==='minutes') ratio = minutes/60;
        if (unit==='seconds') ratio = seconds/60;
        const prog = el.querySelector('.prog');
        if (prog){ prog.style.strokeDasharray = circ; prog.style.strokeDashoffset = circ - circ*ratio; }
      })
    } else if (style === 'bars'){
      document.querySelectorAll('.timer.bars .bar').forEach((el)=>{
        const unit = el.getAttribute('data-unit');
        let ratio = 0;
        if (unit==='days') ratio = Math.min(1, days/30);
        if (unit==='hours') ratio = hours/24;
        if (unit==='minutes') ratio = minutes/60;
        if (unit==='seconds') ratio = seconds/60;
        const fill = el.querySelector('.fill');
        if (fill) fill.style.width = (ratio*100).toFixed(2)+'%';
      })
    } else if (style === 'dots'){
      document.querySelectorAll('.timer.dots .dot-row').forEach((row)=>{
        const wrap = row.querySelector('.dots-wrap');
        const unit = row.getAttribute('data-unit');
        const maxDots = unit==='days'?30:unit==='hours'?24:unit==='minutes'?60:60;
        if (!wrap.hasChildNodes()){
          for (let i=0;i<maxDots;i++){ const d=document.createElement('span'); d.className='dot'; wrap.appendChild(d); }
        }
        const value = unit==='days'?Math.min(30, days):unit==='hours'?hours:unit==='minutes'?minutes:seconds;
        [...wrap.children].forEach((d,idx)=>{ d.style.opacity = idx<value?1:0.14; })
      })
    } else if (style === 'ring'){
      const total = Math.max(1, (target - now)/1000);
      const init = Math.max(1, (target - new Date(window.__init || Date.now()))/1000);
      const ratio = Math.max(0, Math.min(1, total/init));
      const fg = document.querySelector('.timer.ring .ring-fg');
      if (fg) fg.setAttribute('width', (ratio*100).toFixed(2)+'%');
    } else if (style === 'liquid'){
      document.querySelectorAll('.timer.liquid .liquid-meter').forEach((el)=>{
        const unit = el.getAttribute('data-unit');
        let ratio = 0;
        if (unit==='days') ratio = Math.min(1, days/30);
        if (unit==='hours') ratio = hours/24;
        if (unit==='minutes') ratio = minutes/60;
        if (unit==='seconds') ratio = seconds/60;
        const fill = el.querySelector('.liquid-fill');
        if (fill) fill.style.height = (ratio*120)+'px';
      })
    } else if (style === 'typewriter'){
      const out = document.getElementById('typewriter-output');
      if (out){
        const text = `${pad(days)} days ${pad(hours)}h ${pad(minutes)}m ${pad(seconds)}s`;
        if (!out.__prev || out.__prev !== text){ out.textContent = ''; let i=0; clearInterval(out.__timer); out.__timer = setInterval(()=>{ out.textContent += text[i++]||''; if(i>text.length) clearInterval(out.__timer); }, 24); out.__prev = text; }
      }
    }
  }
  window.__init = Date.now();
  update();
  setInterval(update, 1000);
  const form = document.getElementById('notify');
  form.addEventListener('submit', (e)=>{
    const input = form.querySelector('input[type=email]');
    input.disabled = true; setTimeout(()=>{ input.value=''; input.disabled=false; alert('Thanks! We'll be in touch.'); }, 600);
  });
})();
